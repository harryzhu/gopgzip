package cmd

import (
	"archive/tar"
	"io"
	"log"

	"os"
	"strings"
)

func Tar2(src string, dst string) error {
	setFilesMap(src)
	dstTemp := strings.Join([]string{dst, "ing"}, "")
	bufdst, fhdst := NewBufWriter(dstTemp)

	tw := tar.NewWriter(bufdst)

	for fk, fv := range filesMap {
		log.Println(fk)
		log.Println(fv)

		fsrc, fsrcInfo, fhsrc := NewBufReader(fv)

		hdr, err := tar.FileInfoHeader(fsrcInfo, "")
		if err != nil {
			log.Fatal(err)
		}

		err = tw.WriteHeader(hdr)
		if err != nil {
			log.Fatal(err)
		}

		_, err = io.Copy(tw, fsrc)
		if err != nil {
			log.Fatal(err)
		}

		fhsrc.Close()

	}
	tw.Close()
	bufdst.Flush()
	fhdst.Close()

	err := os.Rename(dstTemp, dst)
	if err != nil {
		log.Fatal(err)
	}
	return nil
}
